<?php

 $today=date("Y/m/d", time());
